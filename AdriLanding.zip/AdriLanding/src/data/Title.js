const Title = {
    products : [
        {
            text: 'Book Percy Jackson'
            
        }
    ]
}

export default Title;