const movies = [
    {
        title: "El Ladrón del Rayo",
        director: " Rick Riordan ",
        year:2005,
        image: "OIP.jpeg"
    },
    {
        title: "El Mar de los Monstruos",
        director: "Rick Riordan",
        year:2006,
        image: "libro2.jpg"
    },
    {
        title: "La Maldición del Titán",
        director: "Rick Riordan",
        year: 2008,
        image: "libro3.jpg"
    },
    {
        title: "La Batalla del Laberinto",
        director: "Rick Riordan",
        year: 2012,
        image: "libro4.jpg"
    },
    {
        title: "El Último Héroe del Olimpo",
        director: "Rick Riordan",
        year: 2014,
        image: "libto5.jpeg"
    }
];

export default movies;
