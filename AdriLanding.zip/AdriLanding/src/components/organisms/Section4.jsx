import Description from "../molecules/Description";
function Section4() {
    return (
    <>
        <Description></Description> 
    </>)
}

export default Section4;